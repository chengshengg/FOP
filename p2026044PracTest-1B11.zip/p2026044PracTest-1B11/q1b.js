/* 
	Question 1b
	Name: Kong Cheng Sheng
	Admin No: p2026044
	Class: DIT1B011
	
*/

function typeOfPet() {
    var pet_type = "dog";
    console.log("My pet is a " + myPet());

    function myPet() {
        var other_pet = "cat";
        return other_pet ;
    }

    myPet();
}

typeOfPet();
