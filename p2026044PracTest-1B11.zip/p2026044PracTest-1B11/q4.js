/* 
	Question 4
	Name: Kong Cheng Sheng
	Admin No: p2026044
	Class: DIT1B011
	
*/

let flower = ["Orchid", "Rose", "Sunflower", "Lily", "Peony"];

/*
    TODO: Fill up the code part a
*/
console.log(flower)
/*
    TODO: Fill up the code part b
*/
flower.pop()

/*
    TODO: Fill up the code part c
*/
flower.sort((a,b)=>-1)
console.log(flower)
