/* 
	Question 1a
	Name: Kong Cheng Sheng
	Admin No: p2026044
	Class: DIT1B011
	
*/

x = 2 * 7 ;

function multiplyTen (z) {
  let x  = z * 10 ;
  return x;
}

xTen = multiplyTen (5);

console.log("5 multiply by ten is " + xTen);

console.log("The value of variable x is " + x);
