/* 
    Question 4a
    Name: Kong Cheng Sheng
    Admin No: p2026044
    Class: DIT1B11

*/

let animals = [ "lion", "elephant", "giraffe", "zebra", "monkey", "tiger", "koala" ];

// Question 4a part i 
/* TODO: Add code here */
console.log(animals[3])
// Question 4a part ii 
/* TODO: Add code here */
animals.push("bear")
// Question 4a part iii 
/* TODO: Add code here */
console.log(animals.slice(1, 5))
