function checkFreeAdmission(X, visitorAge) {
    newX = toString(X)
    newAge = toString(visitorAge)
    if (newX in newAge) {
        return true
    } else {
        return false
    }
}

// Your own test cases
// e.g.;

console.log(checkFreeAdmission(3, [12, 13, 21, 33, 18, 23, 31, 32, 33]));

module.exports = checkFreeAdmission;
