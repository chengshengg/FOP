function calculateRewards(trainingLog) {
    let reward = 0
    let currentStart = null;
    let currentLength = 0
    let fail = 0

    for (let i = 0; i < trainingLog.length; i++) {
        if (trainingLog[i] == 'Reward') {
            if (currentStart == null) {
                currentLength ++; // Start of a new reward-sequence
                reward ++
                currentStart = 1
            } 
            
            // Check if this is the end or last element
            if (i == trainingLog.length - 1 || trainingLog[i + 1] == 'Nil') {
                if (currentLength == 3) {
                    reward += 5
                }

                currentStart = null;
                currentLength = 0
                // reset for next sequence
            } 
            else {
                currentLength ++
                reward ++
            }

        } else {
            fail ++
        }
    }
    return reward
    
}


// Your own test cases
// e.g.;

console.log(calculateRewards(['Reward', 'Nil', 'Reward', 'Reward', 'Nil', 'Reward', 'Reward', 'Reward', 'Nil', 'Nil']));

module.exports = calculateRewards;
